package com.example.kronosme

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
