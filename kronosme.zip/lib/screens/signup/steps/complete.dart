import 'package:flutter/material.dart';

Step completeStep = Step(
  title: const Text('Complete'),
  isActive: true,
  content: Column(),
);
